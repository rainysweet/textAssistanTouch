//
//  main.m
//  悬浮框assitouch
//
//  Created by Sven on 16/3/11.
//  Copyright © 2016年 Sven. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
