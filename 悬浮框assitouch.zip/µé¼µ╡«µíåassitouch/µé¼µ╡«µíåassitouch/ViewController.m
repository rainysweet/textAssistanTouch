//
//  ViewController.m
//  悬浮框assitouch
//
//  Created by Sven on 16/3/11.
//  Copyright © 2016年 Sven. All rights reserved.
//

#import "ViewController.h"
#import "HMViewController.h"
@interface ViewController ()
- (IBAction)tiaozhuanClick:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)tiaozhuanClick:(id)sender {
    
    [self presentViewController:[[HMViewController alloc]init] animated:YES completion:nil];
}
@end
