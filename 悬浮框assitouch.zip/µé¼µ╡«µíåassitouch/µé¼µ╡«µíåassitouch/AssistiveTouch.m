//
//  AssistiveTouch.m
//  悬浮框assitouch
//
//  Created by Sven on 16/3/11.
//  Copyright © 2016年 Sven. All rights reserved.
//

#import "AssistiveTouch.h"
#define WIDTH self.frame.size.width
#define HEIGHT self.frame.size.height
#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight [[UIScreen mainScreen] bounds].size.height

@implementation AssistiveTouch
-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.windowLevel = UIWindowLevelAlert + 1;
        [self makeKeyAndVisible];
        
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        _button.backgroundColor = [UIColor redColor];
        _button.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        _button.layer.cornerRadius = frame.size.width/2;
        [_button addTarget:self action:@selector(choose) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_button];
        
        //放一个拖动手势，用来改变控件的位置
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(changePostion:)];
        [_button addGestureRecognizer:pan];
    }
    return self;
}

//按钮事件
-(void)choose
{
    NSLog(@"悬浮窗");
}
//手势事件 －－ 改变位置
-(void)changePostion:(UIPanGestureRecognizer *)pan
{
    /**
     *  在当前指定的View上面移动
     */
    CGPoint point = [pan translationInView:self];
    NSLog(@"%@",NSStringFromCGPoint(point));
    CGRect originalFrame = self.frame;
    if (originalFrame.origin.x >= 0 && originalFrame.origin.x+originalFrame.size.width <= kScreenWidth) {
        originalFrame.origin.x += point.x;
    }
    if (originalFrame.origin.y >= 0 && originalFrame.origin.y+originalFrame.size.height <= kScreenHeight) {
        originalFrame.origin.y += point.y;
    }
    self.frame = originalFrame;
    [pan setTranslation:CGPointZero inView:self];
    
    if (pan.state == UIGestureRecognizerStateBegan) {
        _button.enabled = NO;
    }else if (pan.state == UIGestureRecognizerStateChanged){
        
    } else {
        /**
         *  获得当前控件的位置 调整在频幕上的位置。
         */
        CGPoint panPoint = self.frame.origin;
//        NSLog(@"%@",NSStringFromCGPoint(panPoint));
        
            if(panPoint.x <= kScreenWidth/2)
            {
                if(panPoint.y <= 40+HEIGHT/2 && panPoint.x >= 20+WIDTH/2)
                {
                    [UIView animateWithDuration:0.2 animations:^{
                        self.center = CGPointMake(panPoint.x, HEIGHT/2);
                    }];
                }
                else if(panPoint.y >= kScreenHeight-HEIGHT/2-40 && panPoint.x >= 20+WIDTH/2)
                {
                    [UIView animateWithDuration:0.2 animations:^{
                        self.center = CGPointMake(panPoint.x, kScreenHeight-HEIGHT/2);
                    }];
                }
                else if (panPoint.x < WIDTH/2+15 && panPoint.y > kScreenHeight-HEIGHT/2)
                {
                    [UIView animateWithDuration:0.2 animations:^{
                        self.center = CGPointMake(WIDTH/2, kScreenHeight-HEIGHT/2);
                    }];
                }
                else
                {
                    CGFloat pointy = panPoint.y < HEIGHT/2 ? HEIGHT/2 :panPoint.y;
                    [UIView animateWithDuration:0.2 animations:^{
                        self.center = CGPointMake(WIDTH/2, pointy);
                    }];
                }
            }
            else if(panPoint.x > kScreenWidth/2)
            {
                if(panPoint.y <= 40+HEIGHT/2 && panPoint.x < kScreenWidth-WIDTH/2-20 )
                {
                    [UIView animateWithDuration:0.2 animations:^{
                        self.center = CGPointMake(panPoint.x, HEIGHT/2);
                    }];
                }
                else if(panPoint.y >= kScreenHeight-40-HEIGHT/2 && panPoint.x < kScreenWidth-WIDTH/2-20)
                {
                    [UIView animateWithDuration:0.2 animations:^{
                        self.center = CGPointMake(panPoint.x, kScreenHeight-HEIGHT/2);
                    }];
                }
                else if (panPoint.x > kScreenWidth-WIDTH/2-15 && panPoint.y < HEIGHT/2)
                {
                    [UIView animateWithDuration:0.2 animations:^{
                        self.center = CGPointMake(kScreenWidth-WIDTH/2, HEIGHT/2);
                    }];
                }
                else
                {
                    CGFloat pointy = panPoint.y > kScreenHeight-HEIGHT/2 ? kScreenHeight-HEIGHT/2 :panPoint.y;
                    [UIView animateWithDuration:0.2 animations:^{
                        self.center = CGPointMake(kScreenWidth-WIDTH/2, pointy);
                    }];
                }
            }
        
        CGRect frame = self.frame;
        //记录是否越界
        BOOL isOver = NO;
        
        if (frame.origin.x < 0) {
            frame.origin.x = 0;
            isOver = YES;
        } else if (frame.origin.x+frame.size.width > kScreenWidth) {
            frame.origin.x = kScreenWidth - frame.size.width;
            isOver = YES;
        }
        
        if (frame.origin.y < 0) {
            frame.origin.y = 0;
            isOver = YES;
        } else if (frame.origin.y+frame.size.height > kScreenHeight) {
            frame.origin.y = kScreenHeight - frame.size.height;
            isOver = YES;
        }
        if (isOver) {
            [UIView animateWithDuration:0.3 animations:^{
                self.frame = frame;
            }];
        }
        
        
        _button.enabled = YES;
    }  
}

@end
