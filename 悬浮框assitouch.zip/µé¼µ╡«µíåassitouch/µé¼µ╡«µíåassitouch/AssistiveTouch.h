//
//  AssistiveTouch.h
//  悬浮框assitouch
//
//  Created by Sven on 16/3/11.
//  Copyright © 2016年 Sven. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssistiveTouch : UIWindow

{
    UIButton *_button;
}

-(id) initWithFrame:(CGRect)frame;

@end
